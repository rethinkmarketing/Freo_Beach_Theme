/**
 * If everything goes correctly, on LiteSpeed servers this file loads
 * and resets the display of admin screen.
 */

document.body.classList.remove( 'tf_litespeed' );